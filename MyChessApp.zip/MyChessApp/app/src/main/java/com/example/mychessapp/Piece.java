package com.example.mychessapp;

public class Piece {
    public final static int Blank  = 0;
    public final static int King   = 1;
    public final static int Queen  = 2;
    public final static int Bishop = 3;
    public final static int Knight = 4;
    public final static int Rook   = 5;
    public final static int Pawn   = 6;

    public final static int Black  = 8;
    public final static int White  = 16;

}
