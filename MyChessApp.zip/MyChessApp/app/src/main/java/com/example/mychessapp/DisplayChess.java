package com.example.mychessapp;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/*
public class DisplayChess extends View {
    //Create Variables
    Integer[][] NumSquaresToEdge;

    public DisplayChess(Context context, @Nullable AttributeSet attrs) {

        super(context, attrs);
        initVar();
        toEdgeData();
    }
    public void initVar()
    {
        NumSquaresToEdge = new Integer[64][8];
    }
    public void toEdgeData()
    {
        for(int file = 0; file < 8; file++)
        {
            for(int rank = 0; rank < 8; rank++)
            {
                int numNorth = 7-rank;
                int numSouth = rank;
                int numWest = file;
                int numEast = 7-file;

                int squareIndex = rank * 8 + file;

                NumSquaresToEdge[squareIndex] =
                        new Integer[]{
                                numNorth,
                                numSouth,
                                numWest,
                                numEast,
                                Math.min(numNorth, numWest),
                                Math.min(numSouth, numEast),
                                Math.min(numNorth, numEast),
                                Math.min(numSouth, numWest)
                        };
            }
        }
    }
}
*/