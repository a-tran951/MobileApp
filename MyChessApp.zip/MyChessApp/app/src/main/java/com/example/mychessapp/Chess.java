package com.example.mychessapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.HashMap;
import java.util.Map;

class Chess
{
    //Rank = row
    //File = column
    static String FEN;
    static String positions;
    static String turn;
    static String castleRights;
    static String enPassant;
    static Integer halfMove;
    static Integer fullMove;

    static Integer[] FENBoard;
    static Integer[] attackBoard;

    static HashMap<Character, Integer> symToType;
    static HashMap<Character, Integer> rankToInt;
    static HashMap<Integer, Character> intToRank;

    static Integer typeMask;
    static Integer colorMask;

    public Chess()
    {
        initChess();
    }
    public static void initChess()
    {
        FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
        //FEN = "rnbqkbnr/8/8/8/8/8/8/RNBQKBNR w KQkq - 0 1";
        String[] FENArray = FEN.trim().split(" ");
        positions       = FENArray[0];
        turn            = FENArray[1];
        castleRights    = FENArray[2];
        enPassant       = FENArray[3];
        halfMove        = Integer.parseInt(FENArray[4]);
        fullMove        = Integer.parseInt(FENArray[5]);
        FENBoard        = new Integer[64];
        attackBoard     = new Integer[64];
        symToType       = new HashMap<>();
        rankToInt       = new HashMap<>();
        intToRank       = new HashMap<>();
        for(int i = 0; i < 64; i++)
        {
            FENBoard[i] = Piece.Blank;
            attackBoard[i] = Piece.Blank;
        }

        symToType.put('k',Piece.King);
        symToType.put('q',Piece.Queen);
        symToType.put('b',Piece.Bishop);
        symToType.put('n',Piece.Knight);
        symToType.put('r',Piece.Rook);
        symToType.put('p',Piece.Pawn);

        intToRank.put(0,'a');
        intToRank.put(1,'b');
        intToRank.put(2,'c');
        intToRank.put(3,'d');
        intToRank.put(4,'e');
        intToRank.put(5,'f');
        intToRank.put(6,'g');
        intToRank.put(7,'h');

        rankToInt.put('a',0);
        rankToInt.put('b',1);
        rankToInt.put('c',2);
        rankToInt.put('d',3);
        rankToInt.put('e',4);
        rankToInt.put('f',5);
        rankToInt.put('g',6);
        rankToInt.put('h',7);

        colorMask = 0b11000;
        typeMask = 0b00111;

        FromFenOf("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
        renderScene();
    }
    public static void FromFenOf(String data)
    {
        if(!FEN.equals(data))
        {
            FEN = data;
            renderScene();
        }
    }
    public static void renderScene()
    {

        Integer file = 0, rank = 0;
        for (Character sym: positions.toCharArray())
        {
            if(sym == '/')
            {
                file = 0;
                rank++;
            }
            else if(Character.isDigit(sym))
            {
                for(int i = 0; i < Character.getNumericValue(sym) && file < 8; i++)
                {
                    FENBoard[(8*rank) + file] = 0;
                    file++;
                }
            }
            else
            {
                Integer pieceColor = Character.isUpperCase(sym) ? Piece.White:Piece.Black;
                Integer pieceType = (symToType.get(Character.toLowerCase(sym)) != null) ? symToType.get(Character.toLowerCase(sym)) : Piece.Blank;
                FENBoard[(rank*8)+file] = pieceColor | pieceType;
                file++;
            }
        }
    }
    public static String ToFenOf(Integer[] positions, String turn, String castleRights, String enPassant, Integer halfMove, Integer fullMove)
    {
        String newFen = "";

        String newPositions = "";
        String newTurn = "";
        String newCastleRights = "";
        String newEnPassant = "";
        Integer newHalfMove = 0;
        Integer newFullMove = 0;
        for (Integer i : positions)
        {
            Integer color = i | colorMask;
            Integer type = i | typeMask;

            Integer file = i % 8;
            Integer rank = i / 8;

            if(file == 0)
            {
                newPositions = newPositions + "/";
            }
        }
        newPositions.replaceFirst("/","");

        return newFen;
    }
}

