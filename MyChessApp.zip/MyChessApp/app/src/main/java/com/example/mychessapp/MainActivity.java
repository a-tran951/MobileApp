package com.example.mychessapp;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private SharedPreferences mPreferences;
    private final String SharedPrefFileName = "com.example.mychessapp";
    private EditText name, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.etName);
        pass = findViewById(R.id.etPass);

        findViewById(R.id.btnLogin).setOnClickListener(this::LoginUser);
        findViewById(R.id.btnRegister).setOnClickListener(this::RegisterUser);
    }

    public void RegisterUser(View view)
    {
        mPreferences = getSharedPreferences(SharedPrefFileName, MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = mPreferences.edit();
        prefEditor.putString(name.getText().toString(), pass.getText().toString());
        prefEditor.apply();
        Toast.makeText(this, "User Created", Toast.LENGTH_SHORT).show();
    }

    public void LoginUser(View view)
    {
        mPreferences = getSharedPreferences(SharedPrefFileName,MODE_PRIVATE);
        String password = mPreferences.getString(name.getText().toString(), "");
        if(password.equals(pass.getText().toString()))
        {
            Toast.makeText(this,"Login Success!", Toast.LENGTH_SHORT).show();
            this.setContentView(R.layout.game);
        }
    }
}