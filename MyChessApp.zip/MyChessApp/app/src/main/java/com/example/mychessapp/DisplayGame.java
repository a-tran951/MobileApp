package com.example.mychessapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.PrecomputedText;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class DisplayGame extends View {
    static Canvas c;
    static Map<Integer, Bitmap> bitmaps = new HashMap<>();

    Chess board;
    String fromSpot = "";
    float cellSize = 0;

    private boolean validMove = false;
    static Integer[][] NumSquaresToEdge = new Integer[64][8];
    Integer[] offsetDir = {8,-8,-1,1,7,-7,9,-9};
    Integer[] knightJumps = {15,17,-17,-15,10,-6,6,-10};
    Integer kingCount = 2;

    public DisplayGame(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        PrecomputedMoveData();
        bitmaps.put(Piece.Black|Piece.Rook,BitmapFactory.decodeResource(getResources(),R.drawable.black_rook));
        bitmaps.put(Piece.Black|Piece.Knight,BitmapFactory.decodeResource(getResources(),R.drawable.black_knight));
        bitmaps.put(Piece.Black|Piece.Bishop,BitmapFactory.decodeResource(getResources(),R.drawable.black_bishop));
        bitmaps.put(Piece.Black|Piece.Queen,BitmapFactory.decodeResource(getResources(),R.drawable.black_queen));
        bitmaps.put(Piece.Black|Piece.King,BitmapFactory.decodeResource(getResources(),R.drawable.black_king));
        bitmaps.put(Piece.Black|Piece.Pawn,BitmapFactory.decodeResource(getResources(),R.drawable.black_pawn));

        bitmaps.put(Piece.White|Piece.Rook,BitmapFactory.decodeResource(getResources(),R.drawable.white_rook));
        bitmaps.put(Piece.White|Piece.Knight,BitmapFactory.decodeResource(getResources(),R.drawable.white_knight));
        bitmaps.put(Piece.White|Piece.Bishop,BitmapFactory.decodeResource(getResources(),R.drawable.white_bishop));
        bitmaps.put(Piece.White|Piece.Queen,BitmapFactory.decodeResource(getResources(),R.drawable.white_queen));
        bitmaps.put(Piece.White|Piece.King,BitmapFactory.decodeResource(getResources(),R.drawable.white_king));
        bitmaps.put(Piece.White|Piece.Pawn,BitmapFactory.decodeResource(getResources(),R.drawable.white_pawn));
        bitmaps.put(Piece.Blank, BitmapFactory.decodeResource(getResources(),R.drawable.blank));


        board = new Chess();
        board.renderScene();
    }

    @Override
    public void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        c = canvas;
        drawBoard(canvas, board.attackBoard);
    }
    private void drawBoard(Canvas canvas, Integer[] boardUnderlay)
    {
        Paint paint = new Paint();

        int dark = Color.rgb(100,100,100);
        int light = Color.rgb(150,150,150);
        int validMoves = Color.rgb(80,150,150);
        int attackMoves = Color.rgb(150,80,80);
        for(int rankFile = 0; rankFile < 64; rankFile++)
        {
            int file = rankFile / 8;
            int rank = rankFile % 8;
            cellSize = getWidth() / 8;

            if(boardUnderlay[rankFile] == 1) {
                paint.setColor(validMoves);
            } else if(boardUnderlay[rankFile] == 2) {
                paint.setColor(attackMoves);
            } else if ((rank + file) % 2 == 0 && boardUnderlay[rankFile] == 0) {
                paint.setColor(dark);
            } else if(boardUnderlay[rankFile] == 0) {
                paint.setColor(light);
            }
            canvas.drawRect((rank) * cellSize, (file) * cellSize, cellSize+((rank) * cellSize),cellSize+((file) * cellSize),paint);
        }

        drawPieces();
    }

    public void drawPieces()
    {
        Paint paint = new Paint(Color.BLACK);
        if (board.FENBoard != null) {
            for (int i = 0; i < 64; i++) {
                int file = i / 8;
                int rank = i % 8;
                c.drawBitmap(DisplayGame.bitmaps.get(board.FENBoard[i]), (cellSize * rank), (cellSize * file), paint);
            }
        }
    }

    public void movePiece(String fromCell,String toCell)
    {
        Map<Character, Integer> dictionary = new HashMap<>();
        dictionary.put('a', 0);
        dictionary.put('b', 1);
        dictionary.put('c', 2);
        dictionary.put('d', 3);
        dictionary.put('e', 4);
        dictionary.put('f', 5);
        dictionary.put('g', 6);
        dictionary.put('h', 7);

        Integer fromFile = dictionary.get(fromCell.toCharArray()[0]);
        Integer fromRank = 7 - Integer.parseInt(String.valueOf(fromCell.toCharArray()[1]));
        Integer toFile = dictionary.get(toCell.toCharArray()[0]);
        Integer toRank = 7 - Integer.parseInt(String.valueOf(toCell.toCharArray()[1]));
        if((board.FENBoard[(8*toRank) + toFile] & Move.typeMasking) == Piece.King)
        {
            kingCount--;
        }
        board.FENBoard[(8*toRank) + toFile] = board.FENBoard[(8*fromRank) + fromFile];
        board.FENBoard[(8*fromRank) + fromFile] = Piece.Blank;
        validMove = false;
        fromSpot = "";
        resetAttackMoves();

        this.invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e)
    {
        Map<Integer, Character> dictionary = new HashMap<>();
        dictionary.put(0,'a');
        dictionary.put(1,'b');
        dictionary.put(2,'c');
        dictionary.put(3,'d');
        dictionary.put(4,'e');
        dictionary.put(5,'f');
        dictionary.put(6,'g');
        dictionary.put(7,'h');
        Integer friendlyTeam = (board.turn.toLowerCase() == "w") ? Piece.White : Piece.Black;
        if(e.getAction() == MotionEvent.ACTION_DOWN)
        {
            int col = (int) (e.getX() / cellSize);
            int row = 7 - (int) (e.getY() / cellSize);
            String spot = dictionary.get(col) + "" + row;

            /*
            if((board.FENBoard[(8*row) + col] & Move.colorMasking) != friendlyTeam)
            {
                return true;
            }
            if(board.attackBoard[(8*row)+col] != 0)
            {
                validMove = true;
            }
            else if(board.attackBoard[(8*row)+col] == 0)
            {
                fromSpot = "";
                resetAttackMoves();
            }
             */

            if(!validMove) { //fromSpot.equals("") && board.FENBoard[(8*row) + col] != Piece.Blank
                fromSpot = spot;
                Log.i("ACTION_FROM", fromSpot);
                //getMovesOf(board.FENBoard[(8*row) + col]);
                validMove = true;
            }
            else if (validMove){
                movePiece(fromSpot, spot);
            }
            if(kingCount != 2)
            {
                Chess.initChess();
                kingCount = 2;
                Toast.makeText(this.getContext(), "Complete game", Toast.LENGTH_SHORT).show();
                this.invalidate();
            }

        }
        return true;
    }

    public void getMovesOf(Integer piece)
    {
        Integer friendlyTeam = (board.turn.equals("w")) ? Piece.White : Piece.Black;

        switch (piece & Move.typeMasking)
        {
            case Piece.Pawn:
                generatePawnMoves(friendlyTeam);
                break;
            case Piece.Knight:
                generateKnightMoves(friendlyTeam);
                break;
            case Piece.Rook:
            case Piece.Bishop:
            case Piece.Queen:
                generateLinearMoves(friendlyTeam,piece);
                break;
            case Piece.King:
                generateKingMoves(friendlyTeam);
                break;
        }
        this.invalidate();
    }

    private void generateLinearMoves(Integer friendlyTeam, Integer piece) {
        int firstOffset = ((piece&Move.typeMasking) == Piece.Queen || (piece&Move.typeMasking) == Piece.Rook) ? 0 : 4;
        int endOffset = ((piece&Move.typeMasking) == Piece.Rook) ? 4 : 8;

        for (int dirIndex = firstOffset; dirIndex < endOffset; dirIndex++)
        {
            for(int n = 0; n < NumSquaresToEdge[boardIndexOf(fromSpot)][dirIndex]; n++)
            {
                int endSpot = boardIndexOf(fromSpot) + offsetDir[dirIndex] * (n + 1);
                int pieceOnSpot = board.FENBoard[endSpot];
                if((pieceOnSpot & Move.colorMasking) == friendlyTeam)
                {
                    break;
                }
                else if ((pieceOnSpot & Move.colorMasking) != friendlyTeam && (pieceOnSpot & Move.colorMasking) != 0)
                {
                    board.attackBoard[endSpot] = 2;
                    break;
                }
                else
                {
                    board.attackBoard[endSpot] = 1;
                }

            }
        }
    }



    private void generateKnightMoves(Integer friendlyTeam) {

    }

    private void generatePawnMoves(Integer friendlyTeam) {

    }

    private void generateKingMoves(Integer friendlyTeam) {

    }

    private static void PrecomputedMoveData(){
        for(int file = 0; file < 8; file++)
        {
            for(int rank = 0; rank < 8; rank++)
            {
                int numNorth = 7-rank;
                int numSouth = rank;
                int numWest = file;
                int numEast = 7-file;

                int squareIndex = rank * 8 + file;

                NumSquaresToEdge[squareIndex] =
                        new Integer[]{
                                numNorth,
                                numSouth,
                                numWest,
                                numEast,
                                Math.min(numNorth, numWest),
                                Math.min(numSouth, numEast),
                                Math.min(numNorth, numEast),
                                Math.min(numSouth, numWest)
                        };
            }
        }
    }

    public int boardIndexOf(String fileRank)
    {
        Map<Character, Integer> dictionary = new HashMap<>();
        dictionary.put('a', 0);
        dictionary.put('b', 1);
        dictionary.put('c', 2);
        dictionary.put('d', 3);
        dictionary.put('e', 4);
        dictionary.put('f', 5);
        dictionary.put('g', 6);
        dictionary.put('h', 7);

        Integer fromFile = dictionary.get(fileRank.toCharArray()[0]);
        Integer fromRank = 7 - Integer.parseInt(String.valueOf(fileRank.toCharArray()[1]));

        return (8*fromRank) + fromFile;
    }

    public void resetAttackMoves()
    {
        for(int i = 0; i < 64; i++)
        {
            board.attackBoard[i] = 0;
        }
        this.invalidate();
    }
}

class Move
{
    public static short typeMasking =    0b00111;
    public static short colorMasking =     0b11000;
}
